adk.test <-
function (...) 
{

    na.remove <- function(x){

	na.status <- sapply(x,is.na)
	k <- length(x)
	x.new <- list()
	na.total <- 0
	for( i in 1:k ){
		x.new[[i]] <- x[[i]][!na.status[[i]]]
		na.total <- na.total + sum(na.status[[i]])
	}
	list(x.new=x.new,na.total=na.total)
}
	if (nargs() == 1 & is.list(list(...)[[1]])) {
        samples <- list(...)[[1]]
    }
    else {
        samples <- list(...)
    }
    out <- na.remove(samples)
    na.t <- out$na.total
    if( na.t > 1) cat(paste("\n",na.t," NAs were removed!\n\n"))
    if( na.t == 1) cat(paste("\n",na.t," NA was removed!\n\n"))
    samples <- out$x.new
    k <- length(samples)
    if (k < 2) 
        stop("Must have at least two samples.")
    ns <- sapply(samples, length)
    if (any(ns == 0)) 
        stop("One or more samples have no observations.")
    x <- NULL
    for (i in 1:k) x <- c(x, samples[[i]])
    n <- length(x)
    Z.star <- sort(unique(x))
    L <- length(Z.star)
    AkN2 <- 0
    AakN2 <- 0
    l.vec <- NULL
    for (j in 1:L) {
        fij <- NULL
        for (i in 1:k) {
            fij <- c(fij, as.double(sum(samples[[i]] == Z.star[j])))
        }
        l.vec <- c(l.vec, sum(fij))
    }
    for (i in 1:k) {
        Mij <- as.double(0)
        Maij <- as.double(0)
        inner.sum <- as.double(0)
        inner.sum.a <- as.double(0)
        for (j in 1:L) {
            fij <- sum(samples[[i]] == Z.star[j])
            Mij <- Mij + fij
            Maij <- Mij - fij/2
            Bj <- as.double(sum(l.vec[1:j]))
            Baj <- Bj - l.vec[j]/2
            if (j < L) {
                inner.sum <- inner.sum + l.vec[j] * (n * Mij - 
                  ns[i] * Bj)^2/(Bj * (n - Bj))
            }
            inner.sum.a <- inner.sum.a + l.vec[j] * (n * Maij - 
                ns[i] * Baj)^2/(Baj * (n - Baj) - n * l.vec[j]/4)
        }
        AkN2 <- AkN2 + inner.sum/ns[i]
        AakN2 <- AakN2 + inner.sum.a/ns[i]
    }
    AkN2 <- AkN2/n
    AakN2 <- (n - 1) * AakN2/n^2
    coef.d <- 0
    coef.c <- 0
    coef.b <- 0
    coef.a <- 0
    H <- sum(1/ns)
    h <- sum(1/(1:(n - 1)))
    g <- 0
    for (i in 1:(n - 2)) {
        g <- g + (1/(n - i)) * sum(1/((i + 1):(n - 1)))
    }
    coef.a <- (4 * g - 6) * (k - 1) + (10 - 6 * g) * H
    coef.b <- (2 * g - 4) * k^2 + 8 * h * k + (2 * g - 14 * h - 
        4) * H - 8 * h + 4 * g - 6
    coef.c <- (6 * h + 2 * g - 2) * k^2 + (4 * h - 4 * g + 6) * 
        k + (2 * h - 6) * H + 4 * h
    coef.d <- (2 * h + 6) * k^2 - 4 * h * k
    sig2 <- (coef.a * n^3 + coef.b * n^2 + coef.c * n + coef.d)/((n - 
        1) * (n - 2) * (n - 3))
    sig <- sqrt(sig2)
    TkN <- (AkN2 - (k - 1))/sig
    TakN <- (AakN2 - (k - 1))/sig
    pvalTkN <- adk.pval(TkN, k - 1)
    pvalTakN <- adk.pval(TakN, k - 1)
    pvalTakN[[1]][1]
    return(pvalTakN[[1]][1])
    
    
}

adk.pval <-
function (tx,m) 
{

table1.adk <- cbind(c(1, 2, 3, 4, 6, 8, 10, Inf), c(0.326, 
        0.449, 0.498, 0.525, 0.557, 0.576, 0.59, 0.674), c(1.225, 
        1.309, 1.324, 1.329, 1.332, 1.33, 1.329, 1.282), c(1.96, 
        1.945, 1.915, 1.894, 1.859, 1.839, 1.823, 1.645), c(2.719, 
        2.576, 2.493, 2.438, 2.365, 2.318, 2.284, 1.96), c(3.752, 
        3.414, 3.246, 3.139, 3.005, 2.92, 2.862, 2.326))
    extrap <- FALSE
    mt <- table1.adk[, 1]
    sqm1 <- 1/sqrt(mt)
    sqm2 <- sqm1^2
    tm <- NULL
    p <- c(0.25, 0.1, 0.05, 0.025, 0.01)
    lp <- log(p/(1 - p))
    for (i in 1:5) {
        out <- lsfit(cbind(sqm1, sqm2), table1.adk[, i + 1])
        x <- 1/sqrt(m)
        coef <- out$coef
        y <- coef[1] + coef[2] * x + coef[3] * x^2
        tm <- c(tm, y)
    }
    out <- lsfit(cbind(tm, tm^2), lp)
    coef <- out$coef
    if (tx <= max(tm) & tx >= min(tm)) {
        lp0 <- coef[1] + coef[2] * tx + coef[3] * tx^2
    }
    if (tx > max(tm)) {
        extrap <- TRUE
        lp0 <- min(lp) + (tx - max(tm)) * (coef[2] + 2 * coef[3] * 
            max(tm))
    }
    if (tx < min(tm)) {
        extrap <- TRUE
        lp0 <- max(lp) + (tx - min(tm)) * (coef[2] + 2 * coef[3] * 
            min(tm))
    }
    p0 <- exp(lp0)/(1 + exp(lp0))
    names(p0) <- NULL
    list(p0 = p0, extrap = extrap)
}

"qgrubbs" <-
function(p,n,type=10,rev=FALSE)
{

if (type == 10) {

if (!rev) { 
return(((n-1)/sqrt(n))*sqrt(qt((1-p)/n,n-2)^2/(n-2+qt((1-p)/n,n-2)^2)))
}
else{
s <- (p^2*n*(2-n))/(p^2*n-(n-1)^2)
t <- sqrt(s)
if (is.nan(t)) {
        res <- 0
}
else
{
res <- n*(1-pt(t,n-2))
res[res>1] <- 1
}
return(1-res)
}
}

else if (type == 11) {

if (!rev) {
return(sqrt((2*(n-1)*qt((1-p)/(n*(n-1)),n-2)^2)/(n-2+qt((1-p)/(n*(n-1)),n-2)^2)))
}
else{

q <- p;

p <- vector();

for (i in 1:length(q)) {

if (q[i] > qgrubbs(0.9999,n,type=11)) { pp <- 1 }
else
if (q[i] < qgrubbs(2e-16,n,type=11)) { pp <- 0}

else {
        f <- function(x,q,n) { qgrubbs(x,n,type=11)-q }
        pp <- uniroot(f,c(0.001,0.9999),q=q[i],n=n)$root

}
p <- c(p,pp)

}

return(p)

}

}

else {

if (n > 30) stop("n must be in range 3-30");

pp <- c(0.01,0.025,0.05,0.1,0.15,0.2,0.4,0.6,0.8,0.9,0.95,0.975,0.99);

gtwo <- c(
NA,NA,NA,NA,NA,NA,NA,NA,NA,NA,NA,NA,NA,
NA,NA,NA,NA,NA,NA,NA,NA,NA,NA,NA,NA,NA,
NA,NA,NA,NA,NA,NA,NA,NA,NA,NA,NA,NA,NA,
0.00001,0.0002,0.0008,0.0031,0.007,0.013,0.055,0.138,0.283,0.399,0.482,0.54,0.589,
0.0035,0.009,0.0183,0.0376,0.058,0.078,0.169,0.276,0.41,0.502,0.571,0.63,0.689,
0.0186,0.0349,0.0565,0.0921,0.124,0.153,0.257,0.361,0.478,0.562,0.626,0.674,0.724,
0.044,0.0708,0.102,0.1479,0.186,0.217,0.325,0.423,0.53,0.605,0.659,0.701,0.743,
0.075,0.1101,0.1478,0.1994,0.238,0.271,0.376,0.468,0.568,0.635,0.684,0.722,0.763,
0.1082,0.1492,0.1909,0.2454,0.285,0.319,0.42,0.507,0.598,0.658,0.703,0.738,0.776,
0.1415,0.1865,0.2305,0.2863,0.326,0.358,0.455,0.537,0.622,0.678,0.721,0.753,0.787,
0.1736,0.2212,0.2666,0.3226,0.363,0.394,0.487,0.564,0.624,0.695,0.734,0.765,0.797,
0.2044,0.2536,0.2996,0.3552,0.393,0.424,0.514,0.585,0.66,0.709,0.745,0.773,0.802,
0.2333,0.2836,0.3295,0.3843,0.421,0.451,0.537,0.605,0.676,0.721,0.755,0.782,0.809,
0.2605,0.3112,0.3568,0.4106,0.447,0.477,0.558,0.622,0.689,0.733,0.765,0.789,0.817,
0.2859,0.3367,0.3818,0.4345,0.469,0.497,0.576,0.639,0.701,0.742,0.773,0.797,0.822,
0.3098,0.3603,0.4048,0.4562,0.491,0.518,0.593,0.653,0.713,0.751,0.78,0.803,0.826,
0.3321,0.3822,0.4259,0.4761,0.511,0.536,0.609,0.666,0.723,0.76,0.787,0.808,0.831,
0.353,0.4025,0.4455,0.4944,0.526,0.552,0.622,0.676,0.732,0.767,0.793,0.814,0.835,
0.3725,0.4214,0.4636,0.5113,0.543,0.567,0.635,0.688,0.74,0.774,0.799,0.818,0.838,
0.3909,0.4391,0.4804,0.5269,0.559,0.582,0.647,0.697,0.748,0.781,0.805,0.823,0.843,
0.408,0.457,0.496,0.542,0.571,0.594,0.657,0.706,0.755,0.786,0.81,0.828,0.847,
0.425,0.474,0.512,0.556,0.584,0.606,0.668,0.715,0.762,0.792,0.815,0.834,0.85,
0.442,0.486,0.524,0.568,0.596,0.618,0.677,0.723,0.769,0.797,0.819,0.836,0.853,
0.453,0.5,0.538,0.581,0.608,0.628,0.686,0.73,0.774,0.802,0.823,0.84,0.857,
0.466,0.511,0.547,0.589,0.616,0.637,0.693,0.736,0.779,0.807,0.827,0.843,0.86,
0.482,0.525,0.561,0.601,0.627,0.647,0.701,0.743,0.784,0.811,0.83,0.845,0.861,
0.492,0.536,0.572,0.611,0.636,0.655,0.709,0.749,0.789,0.815,0.834,0.849,0.864,
0.505,0.548,0.583,0.621,0.646,0.664,0.716,0.755,0.794,0.819,0.837,0.851,0.866,
0.516,0.558,0.592,0.629,0.654,0.672,0.722,0.76,0.798,0.822,0.84,0.854,0.869,
0.528,0.568,0.602,0.638,0.661,0.679,0.728,0.765,0.802,0.826,0.842,0.856,0.87);

dim(gtwo) <- c(13,30);

if (!rev) res <- qtable(p,pp,gtwo[,n])
else res <- qtable(p,gtwo[,n],pp)

res[res < 0] <- 0;
res[res > 1] <- 1;


return(res)

}
}

"pgrubbs" <-
function(q,n,type = 10)

{

qgrubbs(q,n,type,rev=TRUE);

}

grubbs.test <-
function (x,type=10,opposite=FALSE,two.sided=FALSE)
{

if (sum(c(10,11,20) == type) == 0) stop ("Incorrect type");


DNAME <- deparse(substitute(x))
x <- sort(x[complete.cases(x)])

n <- length(x);

if (type == 11) 
{
g <- (x[n] - x[1])/sd(x);
u <- var(x[2:(n-1)])/var(x)*(n-3)/(n-1)

pval = 1-pgrubbs(g,n,type=11);

method <- "Grubbs test for two opposite outliers"

alt = paste(x[1],"and",x[n],"are outliers")

}

else if (type == 10)

{
if (xor(((x[n] - mean(x)) < (mean(x) - x[1])),opposite)) {
alt = paste("lowest value",x[1],"is an outlier");
o <- x[1];
d <- x[2:n];
}
else{
alt = paste("highest value",x[n],"is an outlier");
o <- x[n];

d <- x[1:(n-1)];

}

g <- abs(o - mean(x))/sd(x)
u <- var(d)/var(x)*(n-2)/(n-1)

pval <- 1-pgrubbs(g,n,type=10);

method <- "Grubbs test for one outlier"

}

else

{

if (xor(((x[n] - mean(x)) < (mean(x) - x[1])),opposite)) {
alt = paste("lowest values",x[1],",",x[2],"are outliers");
u <- var(x[3:n])/var(x)*(n-3)/(n-1);
}
else{
alt = paste("highest values",x[n-1],",",x[n],"are outliers");
u <- var(x[1:(n-2)])/var(x)*(n-3)/(n-1)
}

g <- NULL

pval <- pgrubbs(u,n,type=20);

method <- "Grubbs test for two outliers"

}

if (two.sided) {
        pval <- 2* pval;
        if (pval > 1) pval <- 2 - pval;
        }


RVAL <- list(statistic = c(G = g, U= u),
alternative = alt, p.value = pval, method = method, 
    data.name = DNAME)
class(RVAL) <- "htest"
hehe=c(pval,o)
return(hehe)

}

ADGWAS<-function(genotype.filename,phenotype.filename,population.filename){
population=read.table(population.filename,sep="\t",head=TRUE)
phenotype=read.table(phenotype.filename,sep="\t",head=TRUE)
genotype=read.table(genotype.filename,sep="\t")
phenotype=phenotype[order(phenotype[,1]),]
population=population[order(population[,1]),]
pp=as.matrix(cbind(unique(phenotype[match(population[,1],phenotype[,1],0L),]),population[match(phenotype[,1],population[,1],0L),]))

subpop_code=unique(pp[,length(pp[1,])])
geno_calculated=t(as.matrix(genotype[,4:length(genotype[1,])]))
geno_calculated=geno_calculated[order(geno_calculated[,1]),]
for (j in 2:length(phenotype[1,])){ 
filename=paste(colnames(pp)[j],".csv",sep="")                            
for (o in 1:length(subpop_code)){                                       
	subpop=cbind(pp[which(pp[,length(pp[1,])]==o),1],pp[which(pp[,length(pp[1,])]==o),j])
	for (snpnum in 2:length(geno_calculated[1,])){
	y=list()
	y=cbind(geno_calculated[,1],geno_calculated[,snpnum])
	qq=cbind(subpop,y[which(match(y[,1],subpop[,1],0L)!=0),2])
   
	qq=qq[which(qq[,2]!=-999),]
	qq=qq[which(qq[,3]!="N"),]
	if (length(qq)!=3){
		b=unique(qq[,3])
		if (length(b)==2){
			dat1=as.double(qq[which(qq[,3]==b[1]),2])
			dat2=as.double(qq[which(qq[,3]==b[2]),2])
			if(length(dat1)>=6 & length(dat2)>=6){
				if(length(unique(dat1))>1){
				pval=grubbs.test(dat1,type=10)
				if(pval[1]<0.05){
				dat1=dat1[dat1!=pval[2]]
				}
				}
				if(length(unique(dat2))>1){
				 pval=grubbs.test(dat2,type=10)
				  if(pval[1]<0.05){
				  dat2=dat2[dat2!=pval[2]]
				 }
				}
				w=adk.test(dat1,dat2)
				result=list()
				result=cbind(genotype[snpnum,1:3],paste("subpop-",o,sep=""),w)
    				write.table(result,file=filename,append=TRUE,row.names=FALSE,col.names=FALSE)
			}
			else{
			     w=adk.test(dat1,dat2)
			     result=list()
			     result=cbind(genotype[snpnum,1:3],paste("subpop-",o,sep=""),w)
			     write.table(result,file=filename,append=TRUE,row.names=FALSE,col.names=FALSE)
			     
			     }
			
		}
		else{
			result=list()
			result=cbind(genotype[snpnum,1:3],paste("subpop-",o,sep=""),1)
			filename=paste(colnames(pp)[j],".csv",sep="")
			write.table(result,file=filename,append=TRUE,row.names=FALSE,col.names=FALSE)
			
		}
	}
	else{
		result=list()
		result=cbind(genotype[snpnum,1:3],paste("subpop-",o,sep=""),1)
		write.table(result,file=filename,append=TRUE,row.names=FALSE,col.names=FALSE)
		
	}
}
	


}
}
}
